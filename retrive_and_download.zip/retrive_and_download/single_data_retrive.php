<html>
<body bgcolor="smokewhite">
<link rel="stylesheet" href="css/single.css">
<div border="01" cellspacing="0">
    <center>
    <h1>Retrive & Export data</h1>
    <div class="container">
        <div class="single">
                <form action="" method="POST">
                <input type="text" name="U_Roll" id="U_Roll" class="btn" placeholder="Enter your University roll number" />
                <input type="submit" name="submit" class="btn" value="search" />                  
                </form>
                <form action="single_data_download.php" method="POST">
                <input type="text" name="U_Roll" id="U_Roll" class="btn" placeholder="Enter your University roll number" />
                <input type="submit" name="export" class="btn" value="download" />                  
                </form>
            </div>    
        <div class="inp">
        <table id="tab" border="01" cellspacing="0">
        <?php
        $connection=mysqli_connect("localhost","root");
        $db=mysqli_select_db($connection,'database123');

                            if(isset($_POST['submit']))
                            {
                                $query=" SELECT * FROM entry_details WHERE U_Roll=$_POST[U_Roll] ";
                                $query_run = mysqli_query($connection,$query);

                                if($res=mysqli_fetch_assoc($query_run)) 
                                {
                                    
                            ?>
                                    <?php echo "Data base of "?>
                                    
                                    <?php echo  $res["first_name"]; ?>
                                    <br><br>
                                    <thead>
                                        <tr>
                                            <th>University_Roll</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Age</th> 
                                            <th>Gender</th>
                                            <th>Email</th> 
                                            <th>Phone</th>
                                            <th>Password</th>  
                                            <th>Session</th> 
                                            
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td><?php echo $res["U_Roll"]; ?></td>
                                            <td><?php echo $res["first_name"]; ?></td>
                                            <td><?php echo $res["last_name"]; ?></td>
                                            <td><?php echo $res["age"]; ?></td>
                                            <td><?php echo $res["gender"]; ?></td>
                                            <td><?php echo $res["email"]; ?></td>
                                            <td><?php echo $res["phone"]; ?></td>
                                            <td><?php echo $res["passcode"]; ?></td>
                                            <td><?php echo $res["session_year"]; ?></td>
                                           
                                            </form>
    </center>                                            
                                        </tr>
                                    </tbody>

                                <?php
                                }else{
                                    echo"Please input valid id";
                                }
                            }
                            elseif(isset($_POST['export'])){                          
                                    include 'DBController.php';
                                    $db_handle = new DBController();
                                    $productResult = $db_handle->runQuery("SELECT * FROM entry_details WHERE U_Roll = $_POST[U_Roll]");

                                    if (isset($_POST["export"])) {
                                        $filename = "Mydatabase_downloader.xls";
                                        header("Content-Type: application/vnd.ms-excel");
                                        header("Content-Disposition: attachment; filename=\"$filename\"");
                                        
                                        $isPrintHeader = false;
                                        if (! empty($productResult)) {
                                            foreach ($productResult as $row) {
                                                if (! $isPrintHeader) {
                                                    echo implode("\t", array_keys($row)) . "\n";
                                                    $isPrintHeader = true;
                                                }
                                                echo implode("\t", array_values($row)) . "\n";
                                            }
                                        }
                                        exit();
                                    }
                                }
                                ?>      
    </table><br><br>
    </div>
    
</body>
</html>