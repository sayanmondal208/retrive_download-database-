<?php

 include 'conn.php';

 if(isset($_POST['done'])){

 $U_Roll = $_GET['U_Roll'];
 $first_name = $_POST['first_name'];
 $last_name = $_POST['last_name'];
 $age=$_POST['age'];
 $gender=$_POST['gender'];
 $email=$_POST['email'];
 $phone=$_POST['phone'];
 $passcode=$_POST['passcode'];
 $session_year=$_POST['session_year'];
 $q = " update entry_details set U_Roll=$U_Roll, first_name='$first_name', last_name='$last_name',age='$age',gender='$gender',email='$email',phone='$phone',passcode='$passcode',session_year='$session_year' where U_Roll=$U_Roll  ";

 $query = mysqli_query($con,$q);

 header('location:single_data_retrive.php');
 }

?>

<!DOCTYPE html>
<html>
<head>
 <title></title>

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>
<body>

 <div class="col-lg-6 m-auto">
 
 <form method="post">
 
 <br><br><div class="card">

 <center>
 <div class="card-header bg-dark">
 <h1 class="text-white text-center">  Update Operation </h1>
 </div><br>
 <table>

 <label> first_name: </label>
 <input type="text" name="first_name" class="form-control"> <br>
<br>
 <label>last_name: </label>
 <input type="text" name="last_name" class="form-control"> <br>
 <br>
 <label>age: </label>
 <input type="text" name="age" class="form-control"> <br>
 <br>
 <label>gender: </label>
 <input type="text" name="gender" class="form-control"> <br>
 <br>
 <label>email: </label>
 <input type="text" name="email" class="form-control"> <br>
 <br>
 <label>phone: </label>
 <input type="text" name="phone" class="form-control"> <br>
 <br>
 <label>password: </label>
 <input type="text" name="passcode" class="form-control"> <br>
 <br>
 <label>session_year: </label>
 <input type="text" name="session_year" class="form-control"> <br>
 <br>
 <button class="btn btn-success" type="submit" name="done"> Submit </button><br>
</table>
</center>
 </div>
 </form>
 </div>
</body>
</html>