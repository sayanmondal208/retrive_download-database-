<?php
$server_name="localhost";
$username="root";
$password="";
$database_name="date_time";

$conn = new mysqli($server_name, $username, $password, $database_name);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT date, time, data FROM info";
$result = $conn->query($sql);

echo "<table border='1'>";
echo "<tr><td> Date </td><td>Time</td><td>Data</td><td> Download text </td><td> Download csv</td>";

if ($result->num_rows > 0) {

        // output data of each row
        while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["date"]. "</td><td>" . $row["time"]. "</td><td>" .$row["data"] ."</td><td><a href='NEEDTXTFILE.php'>".$row["date"].'.txt'. "</a></td>"."<td><a href='NEEDCSVFILE.php'>".$row["date"].'.csv'. "</a></td> ";
        echo "</tr>";    
    }

    echo "</tr>";
    echo "</table>";
} else {
    echo "0 results";
}