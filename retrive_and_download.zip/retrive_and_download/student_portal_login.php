
<?php  
   $email = $_POST['email'];
    $passcode = $_POST['passcode']; 

    $conn=new mysqli("localhost","root","","database123");
    if($conn->connect_error) {
        die("Failed to connect : ". $conn->connect_error);
    }else{
        $stmt = $conn->prepare("select * from student where email= ?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt_result =  $stmt->get_result();
        if($stmt_result->num_rows > 0){
            $data = $stmt_result->fetch_assoc();
            if($data['passcode'] === $passcode){
                echo "congro.....";
            }else{
            ?>
            <center>
            <?php echo "Wrong password .....Pleasae check again" ?>
            <br><br>
            <?php
            echo" please login again......."?><a href="student_login.php">Login</a>     
            <br><br>
            </center>
            <?php  
            }
        }else{
            echo "<h2>invalid email or password</h2>";
            echo " Create a new accout......."?><a href="register.html">Register</a>
<?php
        }
    }
?>
