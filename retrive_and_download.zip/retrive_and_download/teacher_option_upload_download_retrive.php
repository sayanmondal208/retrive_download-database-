<html>
<button><a href="retrive_download.php">search and download data</a></button>
<button><a href="import/index.php">upload data data</a></buttton>
</html>