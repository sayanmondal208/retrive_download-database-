<link rel="stylesheet" href="css/double.css">
<div border="01" cellspacing="0">
    <center>
    <h1>Export data from database and download in csv file</h1>
    <div class="container">
        <div class="double">
                <form action="" method="POST">
                <input type="text" name="session_year" id="session_year" class="btn" placeholder="Enter your registration year" required/>
                    <input type="submit" name="submit" class="btn" value="search" />
                </form>
                
                <form action="multiple_data_download.php" method="POST">
                <input type="text" name="session_year" id="session_year" class="btn" placeholder="Enter your registration year" required/>
                <td><button type="submit" id="btnExport" name='export'value="Export to Excel" class="btn btn-info">Download</button></td>
                </form>
            </div>
<div class="inp">
        <table id="tab" border="01" cellspacing="0">
        <?php
        $connection=mysqli_connect("localhost","root");
        $db=mysqli_select_db($connection,'database123');

                            if(isset($_POST['submit']))
                            {
                                $query=" SELECT * FROM entry_details WHERE session_year = $_POST[session_year] ";
                                $query_run = mysqli_query($connection,$query);
                                ?>
                                <br>
                                <?php echo  "Year of $_POST[session_year] students data" ?>
                                <br>
                                <thead>
                                <tr>
                                    
                                    <th>Session_year</th> 
                                    <th>Id</th> 
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Age</th> 
                                    <th>Gender</th>
                                    <th>Email</th> 
                                    <th>Phone</th>
                                    <th>Password</th>  
                                                                         
                                    
                                </tr>
                            </thead>
                            <?php
                                foreach($query_run as $row) 
                                {        
                            ?>     
                            <br>                              
                                    <tbody>                                    
                                        <tr>
                                            <td><?php echo $row["session_year"]; ?></td>
                                            <td><?php echo $row["U_Roll"]; ?></td>
                                            <td><?php echo $row["first_name"]; ?></td>
                                            <td><?php echo $row["last_name"]; ?></td>
                                            <td><?php echo $row["age"]; ?></td>
                                            <td><?php echo $row["gender"]; ?></td>
                                            <td><?php echo $row["email"]; ?></td>
                                            <td><?php echo $row["phone"]; ?></td>
                                            <td><?php echo $row["passcode"]; ?></td>                                                                          
                                            </form>
    </center>                                            
                                        </tr>
                                    </tbody>

                                <?php
                                }
                            }
                                ?>      
    </table><br><br>
                        </div>
    