
<?php  
$User_email = $_POST['User_email'];
$Password = $_POST['Password'];  

    $conn=new mysqli("localhost","root","","database123");
    if($conn->connect_error) {
        die("Failed to connect : ". $conn->connect_error);
    }else{
        $stmt = $conn->prepare("select * from teacher_login where User_email= ?");
        $stmt->bind_param("s",$User_email);
        $stmt->execute();
        $stmt_result =  $stmt->get_result();
        if($stmt_result->num_rows > 0){
            $data = $stmt_result->fetch_assoc();
            if($data['Password'] === $Password){
            include"teacher_option_upload_download_retrive.php";
            }else{
            ?>
            <center>
            <?php echo "Wrong password .....Pleasae check again" ?>
            <br><br>
            <?php
            echo" please login again......."?><a href="teacher_login.php">Login</a>     
            <br><br>
            </center>
            <?php  
            }
        }else{
            echo "<h2>invalid email or password</h2>";
        }
    }

