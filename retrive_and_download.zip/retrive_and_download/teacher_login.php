<!DOCTYPE html>
<html lan="en" and dir="Itr">
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
    <script src ="js/login.js"> </script>
</head>
<body background="img\5.jpg">
<form action="teacher_portal_login.php" class="box" method="post">
<h1>
    login
</h1>
<input type="text" name="User_email" placeholder="Please input faculty email" required/>
<input type="password" name="Password" placeholder="Enter password" required/>
<input type="submit" name="login" class="form-control">
</form>
</body>
</html>