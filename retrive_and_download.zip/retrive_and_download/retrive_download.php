<!DOCTYPE html>
<html lan="en" and dir="Itr">
<head>
    <meta charset="utf-8">
    <title>MAIN PAGE</title>
    <link rel="stylesheet" href="css/main.css">
</head>
<body background="img/3.jpg">
    <div class="box" method="POST">
        <center>
                <form action="multiple_data_retrive.php"  method="post">
                    <h1>
                        YEAR
                    </h1>
                    <input type="submit" value="SEARCH" name="year" class="form-control">
                </form>
                <form action="single_data_retrive.php" method="post">
                    <h1>
                        UNIVERSITY_ROLL
                    </h1>
                    <input type="submit" value="STUDENT_DATA" name="U_Roll" class="form-control">
                </form>
                <form action="add_student_data.php" method="post">
                    <h1>
                        ADD NEW DATA
                    </h1>
                    <input type="submit" value="ADD" name="add_data" class="form-control">
                </form>           
        </center> 
    </div>      
</body>
</html>