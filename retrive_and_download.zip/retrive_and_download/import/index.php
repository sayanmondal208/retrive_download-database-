<?php
$con=mysqli_connect('localhost','root','','database123');
if(isset($_POST["submit"])){
    require('C:\xampp\htdocs\retrive_and_download\import\PHExcel\PHPExcel.php');
    require('C:\xampp\htdocs\retrive_and_download\import\PHExcel\PHPExcel/IOFactory.php');

    $file=$_FILES["doc"]["tmp_name"];

    $obj=PHPExcel_IOFactory::load($file);
    foreach($obj->getWorksheetIterator()as $sheet){
        $getHighestRow=$sheet->getHighestRow();
        for($i=1;$i<=$getHighestRow;$i++){
            $U_Roll=$sheet->getCellByColumnAndRow(0,$i)->getValue();
            $first_name=$sheet->getCellByColumnAndRow(1,$i)->getValue();
            $last_name=$sheet->getCellByColumnAndRow(2,$i)->getValue();
            $age=$sheet->getCellByColumnAndRow(3,$i)->getValue();
            $gender=$sheet->getCellByColumnAndRow(4,$i)->getValue();
            $email=$sheet->getCellByColumnAndRow(5,$i)->getValue();
            $phone=$sheet->getCellByColumnAndRow(6,$i)->getValue();
            $passcode=$sheet->getCellByColumnAndRow(7,$i)->getValue();
            $session_year=$sheet->getCellByColumnAndRow(8,$i)->getValue();
            if($U_Roll!="U_Roll"){
                mysqli_query($con,"insert into entry_details(U_Roll,first_name,last_name,age,gender,email,phone,passcode,session_year) values('$U_Roll','$first_name','$last_name','$age','$gender','$email','$phone','$passcode','$session_year')");
            }
            
        }
        echo"successfully imported file.........";
        ?>
        <br><br>
        <?php
    }
}
?>
<form method="post" enctype="multipart/form-data">
    <input type="file" name="doc" required/>
    <input type="submit" name="submit"/>
</form>

