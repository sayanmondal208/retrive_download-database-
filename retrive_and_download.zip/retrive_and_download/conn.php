<?php

$con = mysqli_connect('localhost','root');
$db=mysqli_select_db($con,'database123');
mysqli_select_db($con,'data');

?>