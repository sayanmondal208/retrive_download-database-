<!DOCTYPE html>
<html lan="en" and dir="Itr">
<head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
    <script src ="js/login.js"> </script>
</head>
<body background="img\5.jpg">
<form action="student_portal_login.php" class="box" method="post">
<h1>
    login
</h1>
<input type="text" name="email" placeholder="Enter  your registreted email" required/>
<input type="password" name="passcode" placeholder="Enter Password" required/>
<input type="submit" name="login" class="form-control">
<a href="register.html"><p style="color: white;">To create a new account</p></a>
</form>
</body>
</html>