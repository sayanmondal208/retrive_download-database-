<!DOCTYPE html>
<html lan="en" and dir="Itr">
<head>
    <title>register</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/register.css">
    <script src ="js/register.js"> </script>
</head>
<body background="img\4.jpg">
    <div class="main">
        <div class="register">
            <h2>Add student data</h2>
            <form action="details_entry.php" id="register" method="post">
                <lebel>University_roll:</lebel>
                <br>
                <input type="text" name="U_Roll" id="name" placeholder="Enter your university roll" required/>
                <br><br>
                <lebel>First Name:</lebel>
                <br>
                <input type="text" name="first_name" id="name" placeholder="Enter your first name"required/>
                <br><br>
                <label>Last Name:</label>
                <br>
                <input type="text" name="last_name" id="name" placeholder="Enter your last name"required/>
                <br><br>
                
                <lebel>Age:</lebel>
                <br>
                <input type="number" min="1" name="age" id="name" placeholder="Enter your age"required/>
                <br><br>
                <lebel>Gender:</lebel>
                <br>
                <input type="text" name="gender" id="name" placeholder="Enter your age"required/>
                <br><br>
                <lebel>Email:</lebel>
                <br>
                <input type="email" name="email" id="name" placeholder="Enter your valid email"required/>
                <br><br>
                <lebel>phone:</lebel>
                <br>
                <input type="phone" name="phone" id="name" placeholder="Enter your valid phone number"required/>
                <br><br>
                <lebel>Password:</lebel>
                <br>
                <input type="" name="passcode" id="name" placeholder="Enter your password"required/>
                <br><br>
                <lebel>Session year:</lebel>
                <br>
                <input type="text" name="session_year" id="name" placeholder="Enter your session year"required/>
                <br><br>
                <tr>
                    <td colspan="2" align="center" ><input type="submit" name="save" value="Submit" style="font-size:20px" onclick="validate()"></td>
                </tr>
                <br>
            </form>
        </div>
    </div>
</body>
</html>

