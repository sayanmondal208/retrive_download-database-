<?php
$server_name="localhost";
$username="root";
$password="";
$database_name="database123";

$conn=mysqli_connect($server_name,$username,$password,$database_name);
//now check the connection
if(!$conn)
{
	die("Connection Failed:" . mysqli_connect_error());

}

if(isset($_POST['save']))
{	 
	 $U_Roll = $_POST['U_Roll'];
	 $first_name = $_POST['first_name'];
	 $last_name = $_POST['last_name'];
	 $age = $_POST['age'];
	 $gender = $_POST['gender'];
	 $email = $_POST['email'];
	 $phone = $_POST['phone'];
	 $passcode=$_POST['passcode'];

	 $sql_query = "INSERT INTO entry_details (U_Roll,first_name,last_name,age,gender,email,phone,passcode,session_year)
	 VALUES ('$U_Roll','$first_name','$last_name','$age','$gender','$email','$phone','$passcode','$session_year')";

	 if (mysqli_query($conn, $sql_query)) 
	 {
		echo "New Details Entry inserted successfully !";
	 } 
	 else
     {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>