function validate()
{
var username=document.getElementById("username").value;
var email=document.getElementById("email").value;
if(username=="admin"&& email=="useremail")
{
    alert("already register");
    return false;
}
else
{
    alert("register successfully");
}
}