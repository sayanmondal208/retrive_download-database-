<?php

include 'conn.php';

$U_Roll = $_GET['U_Roll'];

$q = " DELETE FROM `entry_details` WHERE U_Roll = $U_Roll ";

mysqli_query($con, $q);

header('location:single_data_retrive.php');

?>